// Main entry point for applicant list page
import "../css/main.css";
import { ApplicantManager } from "./components/ApplicantManager";
import $ from "jquery";

// Make jQuery globally available
window.$ = window.jQuery = $;

// Initialize application when DOM is ready
$(document).ready(() => {
  new ApplicantManager();
});
